# Coursera Capstone project
This is a coursera project meant for back-end Developer Capstone -course.
<br>

Project test URL endpoints:
<br>

*Main site:*
<br>
/restaurant/
<br>

*Menu items (IsAuthenticated):*
<br>
/restaurant/menu/
<br>

*Single Menu Item:*
<br>
restaurant/menu/id/
<br>

for example:
<br>
/restaurant/menu/1/
<br>

*Booking:*
<br>
/restaurant/booking/tables/
<br>

*Djoser authentication and registration:*
<br>
/auth/users/

*Insomnia auth-token test*
<br>
/api-token-auth/
